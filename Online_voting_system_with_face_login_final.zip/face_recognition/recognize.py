
import sys
import face_recognition
import os

KNOWN_FACE_DIR = "face_recognition/known_faces"
TOLERANCE = 0.6

def load_known_faces():
    known_faces = []
    known_names = []
    for name in os.listdir(KNOWN_FACE_DIR):
        for filename in os.listdir(f"{KNOWN_FACE_DIR}/{name}"):
            image = face_recognition.load_image_file(f"{KNOWN_FACE_DIR}/{name}/{filename}")
            encodings = face_recognition.face_encodings(image)
            if encodings:
                known_faces.append(encodings[0])
                known_names.append(name)
    return known_faces, known_names

def recognize_face(image_path):
    known_faces, known_names = load_known_faces()
    unknown_image = face_recognition.load_image_file(image_path)
    unknown_encoding = face_recognition.face_encodings(unknown_image)
    if not unknown_encoding:
        return "NoFaceDetected"
    unknown_encoding = unknown_encoding[0]
    results = face_recognition.compare_faces(known_faces, unknown_encoding, TOLERANCE)
    if True in results:
        return known_names[results.index(True)]
    return "Unknown"

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python recognize.py <image_path>")
        sys.exit(1)
    image_path = sys.argv[1]
    result = recognize_face(image_path)
    print(result)
