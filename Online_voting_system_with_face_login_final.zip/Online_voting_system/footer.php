	  <hr>

      <footer>
        <div class="foot_center"><p>Copyright &copy; 2025 Tilak Maharashtra Vidyapeeth</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: Abhishek Arvind Arjun</p>
		</div>
      </footer>