<h1><font color="gray">Online Voting System</font></h1>
</br>
<font color="#555">
<p>For TILAK MAHARASHTRA UNIVERSITY</p>
<p>Develop By:</p>
</font>
</br>
<div id="accordion2" class="accordion">


<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseOne" data-parent="#accordion2" data-toggle="collapse">Abhishek Arvind Arjun</a>
</div>
<div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
<div class="accordion-inner"> 
<p><font color="gray">Position:&nbsp;Programmer</font></p>
<p><font color="gray">FirstName:&nbsp;Abhishek</font></p>
<p><font color="gray">LastName:&nbsp;Arjun</font></p>
<p><font color="gray">Age:&nbsp;24</font></p>
<p><font color="gray">Address:&nbsp;Pune City</font></p>
<p><font color="gray">Email:&nbsp;abhishekarjun2011@gmail.com</font></p>
<div class="user_image"><img src="project_member/Abhi_profile.jpg" width="200" height="250"></div>
</div>
</div>
</div>


</div>
