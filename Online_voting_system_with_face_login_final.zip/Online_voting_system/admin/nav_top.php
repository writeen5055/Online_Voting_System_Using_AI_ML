	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
 
		<a class="brand">
		<img src="images/Tilak_Icon.png" width="60" height="60">
 	</a>
	<a class="brand">
	 <h2 style="font-family="Times New Roman", Times, serif;>Tilak Maharashtra Vidyapeeth Computer Science Department Voting System</h2>
	 <div class="chmsc_nav"><font size="3" color="white" font-family="Times New Roman", Times, serif;>TILAK MAHARASHTRA UNIVERSITY</font></div>
 	</a>

	<?php include('head.php'); ?>
 
 
	</div>
	</div>
	</div>
	