
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['image_data'])) {
    $data = $_POST['image_data'];

    $image_parts = explode(";base64,", $data);
    $image_base64 = base64_decode($image_parts[1]);

    $fileName = "uploads/face_capture_" . time() . ".png";
    if (!file_exists("uploads")) {
        mkdir("uploads", 0777, true);
    }
    file_put_contents($fileName, $image_base64);

    $output = shell_exec("python3 face_recognition/recognize.py " . escapeshellarg($fileName));

    if (trim($output) === "admin") {
        header("Location: admin_dashboard.php");
        exit();
    } elseif (trim($output) === "user") {
        header("Location: user_dashboard.php");
        exit();
    } elseif (trim($output) === "NoFaceDetected") {
        echo "❌ No face detected. Please try again.";
    } else {
        echo "❌ Face not recognized.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Face Login</title>
</head>
<body>
    <h2>Login with Face Recognition</h2>
    <video id="video" width="300" height="225" autoplay></video>
    <canvas id="canvas" width="300" height="225" style="display:none;"></canvas>
    <form method="POST">
        <input type="hidden" name="image_data" id="image_data">
        <button type="button" onclick="capture()">Capture & Login</button>
    </form>

    <script>
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const imageDataInput = document.getElementById('image_data');

        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                video.srcObject = stream;
            });

        function capture() {
            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataURL = canvas.toDataURL('image/png');
            imageDataInput.value = dataURL;
            document.forms[0].submit();
        }
    </script>
</body>
</html>
